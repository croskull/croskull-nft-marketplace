<div class="wfob_content_sec <?php echo $enable_pointer; ?>">
    <label for="<?php echo $product_key; ?>" class="wfob_title"> <?php echo do_shortcode( $titleHeading ); ?> </label>
</div>