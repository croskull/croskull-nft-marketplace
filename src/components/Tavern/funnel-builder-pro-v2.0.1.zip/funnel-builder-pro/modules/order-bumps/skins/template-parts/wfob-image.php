
	<div class="wfob_pro_img_wrap">
		<?php
		include WFOB_SKIN_DIR . '/image.php'
		?>
	</div>
