<?php
if ( wc_string_to_bool( $design_data['header_enable_pointing_arrow'] ) ) {
	if ( '1' == $design_data['point_animation'] ) {
		$blink_url = WFOB_PLUGIN_URL . '/assets/img/arrow-blink.gif';
	} else {
		$blink_url = WFOB_PLUGIN_URL . '/assets/img/arrow-no-blink.gif';
	}
	$enable_pointer = 'wfob_enable_pointer';
	?>
	<span class="wfob_blink_img_wrap"><img src="<?php echo $blink_url; ?>"></span>

	<?php
}
