<?php

if ( $enable_price ) {
	?>
	<div class=" wfob_price_container ">
		<div class="wfob_price">
			<?php
			echo $printed_price;
			?>
		</div>
	</div>
<?php } ?>