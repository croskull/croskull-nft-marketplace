<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
/**
 * @var $this WFOB_Bump;
 * @var $wc_product WC_Product;
 */

$cart_item_key       = '';
$cart_item           = [];
$result              = WFOB_Common::get_cart_item_key( $product_key );
$is_variable_product = false;

$parent_id = absint( $data['id'] );

if ( $data['parent_product_id'] && $data['parent_product_id'] > 0 ) {
	$parent_id = absint( $data['parent_product_id'] );
}

if ( ! is_null( $result ) ) {
	$cart_item_key = $result[0];
	$cart_item     = $result[1];
}
$qty               = absint( $data['quantity'] );
$cart_variation_id = 0;
if ( ! empty( $cart_item ) && ! is_null( $cart_item ) ) {
	$qty        = $cart_item['quantity'];
	$wc_product = $cart_item['data'];
	if ( isset( $cart_item['variation_id'] ) ) {
		$cart_variation_id = $cart_item['variation_id'];
	}
} else {
	if ( isset( $data['variable'] ) ) {
		$is_variable_product = true;
		$variation_id        = absint( $data['default_variation'] );
		$wc_product          = WFOB_Common::wc_get_product( $variation_id );
	} else {
		$wc_product = WFOB_Common::wc_get_product( $data['id'] );
	}
}

if ( ! $wc_product instanceof WC_Product ) {
	return;
}

if ( ! $wc_product->is_purchasable() && '' == $cart_item_key ) {
	return '';
}

$wc_product  = WFOB_Common::set_product_price( $wc_product, $data, $cart_item_key );
$design_data = $this->get_design_data();

$parent_product = WFOB_Common::wc_get_product( $parent_id );
$product_title  = '';
if ( ! isset( $design_data["product_{$product_key}_title"] ) || '' == $design_data["product_{$product_key}_title"] ) {
	$product_title = $wc_product->get_title();
	if ( in_array( $wc_product->get_type(), WFOB_Common::get_variation_product_type() ) ) {
		if ( absint( $data['parent_product_id'] ) > 0 || '' !== $cart_item_key ) {
			$product_title = $wc_product->get_name();
		}
	}
	$product_title = __( 'Yes, I will take it!', 'woofunnels-order-bump' );
} else {
	$product_title = $design_data["product_{$product_key}_title"];
}

$description = '';
if ( ! isset( $design_data["product_{$product_key}_description"] ) || '' == $design_data["product_{$product_key}_description"] ) {
	$description = $parent_product->get_short_description();
} else {
	$description = $design_data["product_{$product_key}_description"];
}

$featured_image = true;
if ( ! isset( $design_data["product_{$product_key}_featured_image"] ) || '' == $design_data["product_{$product_key}_featured_image"] ) {
	$featured_image = true;
} else {
	$featured_image = $design_data["product_{$product_key}_featured_image"];
}


$price_data = apply_filters( 'wfob_product_switcher_price_data', [], $wc_product );
if ( empty( $price_data ) ) {
	$price_data['regular_org'] = $wc_product->get_regular_price( 'edit' );
	$price_data['price']       = $wc_product->get_price( 'edit' );
}

$price_data['regular_org'] *= $qty;
$price_data['price']       *= $qty;
$price_data['quantity']    = $qty;

$enable_price = true;


if ( isset( $design_data['enable_price'] ) ) {
	if ( '0' === $design_data['enable_price'] || false === wc_string_to_bool( $design_data['enable_price'] ) ) {
		$enable_price = false;
	}
}

$variation_attributes = [];
$product_attributes   = [];
if ( ! is_null( $cart_item ) && isset( $cart_item['variation_id'] ) ) {
	if ( is_array( $cart_item['variation'] ) && count( $cart_item['variation'] ) ) {
		$product_attributes = $cart_item['variation'];
	} elseif ( 'variation' == $cart_item['data']->get_type() ) {
		$product_attributes = $cart_item['data']->get_attributes();
	}
} elseif ( 'variation' == $wc_product->get_type() ) {
	$product_attributes = $wc_product->get_attributes();
}
$variable_checkbox = '';
if ( isset( $data['variable'] ) && $cart_variation_id == 0 ) {
	$variable_checkbox = 'wfob_choose_variation';
}
$enable_pointer = '';
if ( '' !== $cart_item_key ) {
	$price_data = WFOB_Common::get_cart_product_price_data( $wc_product, $cart_item, $cart_item['quantity'] );
} else {
	$price_data             = WFOB_Common::get_product_price_data( $wc_product, $price_data );
	$price_data['quantity'] = $qty;
}

$printed_price = '';
if ( apply_filters( 'wfob_show_product_price', true, $wc_product, $cart_item_key, $price_data ) ) {
	if ( in_array( $wc_product->get_type(), WFOB_Common::get_subscription_product_type() ) ) {
		$printed_price = wc_price( WFOB_Common::get_subscription_price( $wc_product, $price_data, $cart_item_key ) );
	} else {
		if ( $price_data['price'] > 0 && ( absint( $price_data['price'] ) !== absint( $price_data['regular_org'] ) ) ) {
			$printed_price = wc_format_sale_price( $price_data['regular_org'], $price_data['price'] );
		} else {
			$printed_price = wc_price( $price_data['price'] );
		}
	}
} else {
	$printed_price = apply_filters( 'wfob_show_product_price_placeholder', $printed_price, $wc_product, $cart_item_key, $price_data );
}
$output_response    = WFOB_AJAX_Controller::output_resp();
$wfob_error_message = '';
if ( ! empty( $output_response ) && false == $output_response['status'] && isset( $output_response['error'] ) && $output_response['wfob_id'] == $this->get_id() && $output_response['wfob_product_key'] == $product_key ) {
	$wfob_error_message = $output_response['error'];
}

if ( apply_filters( 'wfob_do_not_display_order_bump_product', false, $this->get_id(), $wc_product, $cart_item_key ) ) {
	return 'success';
}
$featured_image     = wc_string_to_bool( $featured_image );
$image_position_cls = '';
$image_width        = '';
$img_position       = '';
if ( $featured_image ) {


	if ( isset( $design_data["product_{$product_key}_featured_image_options"] ) && isset( $design_data["product_{$product_key}_featured_image_options"]['position'] ) ) {
		$bump_id = $this->get_id();

		$image_width  = $design_data["product_{$product_key}_featured_image_options"]['width'];
		$inline_style = '';
		$inline_style .= '<style>@media (min-width: 768px) {';
		$inline_style .= 'body #wfob_wrap .wfob_wrapper .wfob_bump[data-product-key="' . $product_key . '"]:not(.wfob_img_position_top) .wfob_skin_wrap .wfob_contentBox .wfob_pro_txt_wrap{ width: calc(100% - ' . $image_width . 'px);}';
		$inline_style .= 'body #wfob_wrap .wfob_wrapper .wfob_bump[data-product-key="' . $product_key . '"] .wfob_skin_wrap .wfob_contentBox .wfob_pro_img_wrap{ width: ' . $image_width . 'px;}';
		$inline_style .= '}</style>';
		echo $inline_style;


	}
}
if ( isset( $design_data["product_{$product_key}_featured_image_options"] ) && isset( $design_data["product_{$product_key}_featured_image_options"]['position'] ) ) {
	$img_position = $design_data["product_{$product_key}_featured_image_options"]['position'];

	$image_position_cls = 'wfob_img_position_' . $img_position;
}
$titleHeading = WFOB_Common::decode_merge_tags( $product_title, $price_data, $wc_product, $data, $cart_item, $cart_item_key, $product_key, $design_data );

$header_enable_pointing_arrow = "false";
if ( isset( $design_data['header_enable_pointing_arrow'] ) ) {
	$header_enable_pointing_arrow = $design_data['header_enable_pointing_arrow'];
}

$selected_layout = '';
if ( isset( $design_data['layout'] ) ) {
	$selected_layout = $design_data['layout'];
}


?>
    <div id="wfob_wrap" class="wfob_wrap_start">

		<?php do_action( 'wfob_before_wrapper', $this->get_id(), $wc_product, $product_key, $cart_item_key ); ?>
        <div class="<?php echo implode( ' ', [ 'wfob_wrapper', "wfob_" . $selected_layout ] ) ?>" data-wfob-id="<?php echo $this->get_id(); ?>">
            <div class="wfob_bump wfob_clear <?php echo $image_position_cls ?>" data-product-key="<?php echo $product_key; ?>" data-wfob-id="<?php echo $this->get_id(); ?>" cart_key="<?php echo $cart_item_key; ?>">
                <div class="wfob_outer">
                    <div class="wfob_Box wfob_skin_wrap">

                        <div class="wfob_contentBox wfob_clear">

							<?php
							if ( wc_string_to_bool( $featured_image ) && "right" !== $img_position ) {
								include __DIR__ . "/template-parts/wfob-image.php";
							}

							$decode_merge_tags = WFOB_Common::decode_merge_tags( $description, $price_data, $wc_product, $data, $cart_item, $cart_item_key, $product_key, $design_data );
							?>
                            <div class="wfob_pro_txt_wrap">
								<?php
								/* Layout 5 desciption first */
								if ( 'layout_5' === $selected_layout ) {

									include __DIR__ . "/template-parts/wfob-desciption.php";

									include __DIR__ . "/template-parts/wfob-price.php";
								}
								?>


                                <div class="wfob_bgBox_table no_table">
                                    <div class="wfob_check_container">
										<?php
										$disabled = '';
										if ( true === apply_filters( 'wfob_disabled_checkbox', false, $product_key ) ) {
											$disabled = "disabled";
										}
										if ( 'layout_5' === $selected_layout ) {
											?>

                                            <div class="wfob_check_wrap <?php echo "wfob_arrow_" . $header_enable_pointing_arrow; ?>">
												<?php
												if ( 'layout_5' === $selected_layout ) {
													include __DIR__ . "/template-parts/wfob-pointer.php";
												}


												?>
                                                <span class="wfob_bump_checkbox">
                                                   <input type="checkbox" name="<?php echo $product_key; ?>" id="<?php echo $product_key; ?>" data-value="<?php echo $product_key; ?>" class="wfob_checkbox <?php echo '' != $variable_checkbox ? $variable_checkbox : 'wfob_bump_product'; ?>" <?php echo '' != $cart_item_key ? 'checked' : ''; ?> <?php echo $disabled; ?>>
                                            </span>


                                            </div>

											<?php
											include __DIR__ . "/template-parts/wfob-title.php";
											?>

                                            <div class="wfob_error_message"><?php echo $wfob_error_message ?></div>
											<?php
										} else {
											?>
                                            <div class="wfob_bgBox_table">
                                                <div class="wfob_bgBox_tablecell wfob_check_container">
                                                    <label for="<?php echo $product_key; ?>" class="wfob_title"> <?php echo do_shortcode( $titleHeading ); ?> </label>
                                                    <input type="checkbox" name="<?php echo $product_key; ?>" id="<?php echo $product_key; ?>" data-value="<?php echo $product_key; ?>" class="wfob_checkbox wfob-switch <?php echo '' != $variable_checkbox ? $variable_checkbox : 'wfob_bump_product'; ?>" <?php echo '' != $cart_item_key ? 'checked' : ''; ?> <?php echo $disabled; ?>>
                                                    <label for="<?php echo $product_key; ?>"><span class="sw"></span></label>
                                                </div>
                                            </div>
											<?php

										}

										?>

                                    </div>
                                </div>

								<?php


								if ( 'layout_6' === $selected_layout ) {
									include __DIR__ . "/template-parts/wfob-desciption.php";
									include __DIR__ . "/template-parts/wfob-price.php";

								}
								include __DIR__ . "/template-parts/wfob-variation.php";


								?>
                            </div>

							<?php
							if ( wc_string_to_bool( $featured_image ) && "right" === $img_position ) {

								include __DIR__ . "/template-parts/wfob-image.php";
							}
							?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php do_action( 'wfob_after_wrapper', $this->get_id(), $wc_product, $product_key, $cart_item_key ); ?>
    </div>
<?php
return 'success';
