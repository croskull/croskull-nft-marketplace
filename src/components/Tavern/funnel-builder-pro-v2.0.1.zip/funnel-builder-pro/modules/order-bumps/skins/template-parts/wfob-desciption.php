<?php
echo '<div class="wfob_text_inner"><p>' . do_shortcode( $decode_merge_tags ) . '</p></div>';
