<?php

class WFOB_Compatibilities_WoodMart_Builder {
	public function __construct() {
		add_filter( 'wfob_product_switcher_price_data', [ $this, 'remove_action' ] );
		add_filter( 'wfob_qv_images', [ $this, 'remove_action' ], - 1 );
	}

	public function remove_action( $status ) {
		if ( function_exists( 'woodmart_lazy_attributes' ) ) {
			remove_action( 'wp_get_attachment_image_attributes', 'woodmart_lazy_attributes', 10 );
		}

		return $status;
	}


}

WFOB_Plugin_Compatibilities::register( new WFOB_Compatibilities_WoodMart_Builder(), 'WooMart_theme' );
