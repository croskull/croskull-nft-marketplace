<?php global $wfob_is_rules_saved; ?>
<div id="wfob_bump_rule_add_settings" data-is_rules_saved="no">
    <div class="wfob_welcome_wrap">
        <div class="wfob_welcome_wrap_in">
            <div class="wfob_welc_head">
                <div class="wfob_welc_icon"><span class="dashicons dashicons-info"></div>
                <div class="wfob_welc_title"> <?php esc_html_e( 'Rules for this variant are already set', 'woofunnels-upstroke-one-click-upsell' ); ?></div>
            </div>
            <div class="wfob_welc_text"><p><?php esc_html_e( 'Rules for this bump variant will be the same as that of the original variant.', 'woofunnels-upstroke-one-click-upsell' ); ?></p></div>
        </div>
    </div>
</div>