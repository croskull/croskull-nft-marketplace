<?php global $wfob_is_rules_saved; ?>
<script type="text/template" id="wfob-rule-template-basic">
	<?php include 'metabox-rules-rule-template-basic.php'; ?>
</script>



<div class="wfob_success_modal" style="display: none" id="modal-rules-settings_success" data-iziModal-icon="icon-home">


</div>
</form>
</div>
