<?php
defined( 'ABSPATH' ) || exit;
?>
<div class="wfob_qv-opac"></div>
<div class="wfob_qv-panel">
    <div class="wfob_qv-preloader wfob_qv-opl">
        <div class="wfob_qv-speeding-wheel"></div>
    </div>
    <div class="wfob_qv-modal"></div>
</div>
