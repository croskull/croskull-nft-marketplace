<?php
/** WooCommerce all thing subscription plugin rule */
class WFOCU_Rule_Order_Subs extends WFOCU_Rule_Base {
	public $supports = array( 'cart', 'order' );

	public function __construct() {
		parent::__construct( 'order_subs' );
	}

	public function get_possible_rule_operators() {

		$operators = array(
			'>' => __( 'contains at least', 'woofunnels-upstroke-one-click-upsell' ),
			'<' => __( 'contains less than', 'woofunnels-upstroke-one-click-upsell' ),

			'==' => __( 'contains exactly', 'woofunnels-upstroke-one-click-upsell' ),
			'!=' => __( "does not contains at least", 'woofunnels-upstroke-one-click-upsell' ),
		);

		return $operators;
	}

	public function get_condition_input_type() {
		return 'Subs_Product_Select';
	}

	public function is_match( $rule_data, $env = 'cart' ) {

		$products       = $rule_data['condition']['products'];
		$quantity       = $rule_data['condition']['qty'];
		$type           = $rule_data['operator'];
		$found_quantity = 0;
		if ( $env === 'cart' ) {

			$cart_contents = (array) WC()->cart->cart_contents;
			if ( $cart_contents && is_array( $cart_contents ) && count( $cart_contents ) > 0 ) {
				foreach ( $cart_contents as $cart_item ) {
					$productID   = $cart_item['product_id'];
					$variationID = $cart_item['variation_id'];
					if ( absint( $productID ) === 0 ) {
						if ( $cart_item['data'] instanceof WC_Product_Variation ) {
							$productID = $cart_item['data']->get_parent_id();
						} elseif ( $cart_item['data'] instanceof WC_Product ) {
							$productID = $cart_item['data']->get_id();
						}
					}
					if ( isset( $cart_item['wcsatt_data'] ) && isset( $cart_item['wcsatt_data']['active_subscription_scheme'] ) ) {
						$subs_productID   = $productID;
						$subs_variationID = $variationID;
						if( ! empty($cart_item['wcsatt_data']['active_subscription_scheme']) ) {
							$subs_productID   = $productID . '-' . $cart_item['wcsatt_data']['active_subscription_scheme'];
							$subs_variationID = $variationID . '-' . $cart_item['wcsatt_data']['active_subscription_scheme'];
						}
						if ( $subs_productID === $products || ( ( $subs_productID ) && $subs_variationID === $products ) ) { //phpcs:ignore WordPress.PHP.StrictComparisons.LooseComparison
							$found_quantity += $cart_item['quantity'];
						}
					}
				}
			}
		} else {
			$order_id = WFOCU_Core()->rules->get_environment_var( 'order' );
			$order    = wc_get_order( $order_id );
			if ( $order->get_items() && is_array( $order->get_items() ) && count( $order->get_items() ) ) {
				foreach ( $order->get_items() as $cart_item ) {

					$product   = WFOCU_WC_Compatibility::get_product_from_item( $order, $cart_item );
					$productID = $product->get_id();

					$productID = ( $product->get_parent_id() ) ? $product->get_parent_id() : $productID;

					if ( version_compare( WC()->version, '3.0', '>=' ) ) {
						$variationID = $cart_item->get_variation_id();
					} else {
						$variationID = ( is_array( $cart_item['variation_id'] ) && count( $cart_item['variation_id'] ) > 0 ) ? $cart_item['variation_id'][0] : 0;
					}

					if ( isset( $cart_item['wcsatt_data'] ) && isset( $cart_item['wcsatt_data']['active_subscription_scheme'] ) ) {
						$subs_productID   = $productID;
						$subs_variationID = $variationID;
						if( ! empty($cart_item['wcsatt_data']['active_subscription_scheme']) ) {
							$subs_productID   = $productID . '-' . $cart_item['wcsatt_data']['active_subscription_scheme'];
							$subs_variationID = $variationID . '-' . $cart_item['wcsatt_data']['active_subscription_scheme'];
						}
						if ( $subs_productID === $products || ( ( $subs_productID ) && $subs_variationID === $products ) ) {//phpcs:ignore WordPress.PHP.StrictComparisons.LooseComparison
							$found_quantity += $cart_item['qty'];
						}
					}
				}
			}
		}
		if ( $found_quantity === 0 ) {
			if ( '!=' === $type ) {
				return $this->return_is_match( true, $rule_data );
			}

			return $this->return_is_match( false, $rule_data );
		}
		switch ( $type ) {
			case '<':
				$result = $quantity > $found_quantity;
				break;
			case '>':
				$result = $quantity <= $found_quantity;
				break;
			case '==':
				$result = absint( $quantity ) === absint( $found_quantity );
				break;
			case '!=' :
				$result = ! ( $quantity <= $found_quantity );
				break;
			default:
				$result = false;
				break;
		}

		return $this->return_is_match( $result, $rule_data );
	}

}
