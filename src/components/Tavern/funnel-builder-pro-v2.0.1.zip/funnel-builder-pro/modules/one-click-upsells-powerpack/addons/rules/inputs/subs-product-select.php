<?php

/* Note: WooCommerce all thing subscription plugin product search */

class wfocu_Input_Subs_Product_Select {

	public function __construct() {
		// vars
		$this->type = 'Subs_Product_Select';

		$this->defaults = array(
			'multiple'      => 0,
			'allow_null'    => 0,
			'choices'       => array(),
			'default_value' => '',
			'class'         => 'ajax_chosen_subs_select_products'
		);
	}

	public function render( $field, $value = null ) {
		$field = array_merge( $this->defaults, $field );
		if ( ! isset( $field['id'] ) ) {
			$field['id'] = sanitize_title( $field['id'] );
		}

		?>

		<table style="width:100%;">
			<tr>
				<td style="width:32px;"><?php _e( 'Quantity', 'woofunnels-upstroke-one-click-upsell' ); ?></td>
				<td><?php _e( 'Products', 'woofunnels-upstroke-one-click-upsell' ); ?></td>
			</tr>
			<tr>
				<td style="width:32px; vertical-align:top;">
					<input type="text" id="<?php echo $field['id']; ?>_qty" name="<?php echo $field['name']; ?>[qty]" value="<?php echo isset( $value['qty'] ) ? $value['qty'] : 1; ?>"/>

				</td>
				<td>
					<select id="<?php echo $field['id']; ?>" name="<?php echo $field['name']; ?>[products]" class="ajax_chosen_subs_select_products" data-placeholder="<?php _e( 'Look for a product&hellip;', 'woocommerce' ); ?>">
						<?php
						$products = WFOCU_Plugin_Compatibilities::get_compatibility_class( 'wfocu_wc_atts' )->subs_product_search( 'get_data' );
						$current  = isset( $value['products'] ) ? array( $value['products'] ) : array();
						$selected  = '';
						if( isset($current[0])){
							$selected = $current[0];
						}

						if ( is_array( $products ) && count( $products ) > 0 ) {
							foreach ( $products as $product_id => $product_name ) {
								echo "<option value='" . esc_attr( $product_id ) . "' " . selected( $selected, $product_id, false ) . ">" . ( $product_name ) . "</option>";
							}
						}
						?>
					</select>
				</td>
			</tr>
		</table>
		<?php
	}

}

?>