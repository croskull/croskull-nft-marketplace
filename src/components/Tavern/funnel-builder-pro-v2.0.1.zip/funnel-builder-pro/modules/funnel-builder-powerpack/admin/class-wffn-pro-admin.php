<?php
defined( 'ABSPATH' ) || exit; //Exit if accessed directly

/**
 * Class to initiate admin functionality
 * Class WFFN_Pro_Admin
 */
class WFFN_Pro_Admin {

	private static $ins = null;

	/**
	 * WFFN_Pro_Admin constructor.
	 */
	public function __construct() {
		add_filter( 'wffn_funnel_settings', array( $this, 'funnel_settings_localized' ) );

		add_action( 'admin_init', array( $this, 'maybe_show_wizard' ) );
	}

	/**
	 * @return WFFN_Pro_Admin|null
	 */
	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self;
		}

		return self::$ins;
	}

	public function maybe_show_wizard() {
		if ( ! WFFN_Core()->admin->is_wffn_flex_page( 'all' ) ) {// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		if ( isset( $_GET['tab'] ) && strpos( wc_clean( $_GET['tab'] ), 'wizard' ) !== false ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		if ( WFFN_PRO_Core()->support->is_license_present() === false ) {
			wp_redirect( admin_url( 'admin.php?page=woofunnels&tab=' . WFFN_SLUG . '-wizard' ) );
			exit;
		}

	}

	public function funnel_settings_localized( $settings ) {
		$settings_pro      = array(
			'override_tracking_ids' => array(
				array( 'text' => __( 'Facebook Pixel ID', 'funnel-builder' ), 'key' => 'fb_pixel_key' ),

			)

		);
		$is_conversion_api = BWF_Admin_General_Settings::get_instance()->get_option( 'is_fb_purchase_conversion_api' );
		if ( is_array( $is_conversion_api ) && count( $is_conversion_api ) > 0 && 'yes' === $is_conversion_api[0] ) {
			array_push( $settings_pro['override_tracking_ids'], array(
				'text' => __( 'Conversion API Access Token', 'funnel-builder' ),
				'key'  => 'conversion_api_access_token',
				'type' => 'textarea'
			) );
			array_push( $settings_pro['override_tracking_ids'], array(
				'text' => __( 'Conversion API Test event code', 'funnel-builder' ),
				'key'  => 'conversion_api_test_event_code'
			) );
		}
		$settings_pro['override_tracking_ids'][] = array( 'text' => __( 'Google Analytics ID', 'funnel-builder' ), 'key' => 'ga_key' );
		$settings_pro['override_tracking_ids'][] = array( 'text' => __( 'Google Ads Conversion ID', 'funnel-builder' ), 'key' => 'gad_key' );
		$settings_pro['override_tracking_ids'][] = array( 'text' => __( 'Google Ads Conversion Label', 'funnel-builder' ), 'key' => 'gad_conversion_label' );
		$settings_pro['override_tracking_ids'][] = array( 'text' => __( 'Pinterest Tag ID', 'funnel-builder' ), 'key' => 'pint_key' );
		$settings_pro['override_tracking_ids'][] = array( 'text' => __( 'TikTok Pixel ID', 'funnel-builder' ), 'key' => 'tiktok_pixel' );
		$settings_pro['override_tracking_ids'][] = array( 'text' => __( 'Snapchat Pixel ID', 'funnel-builder' ), 'key' => 'snapchat_pixel' );

		return array_merge( $settings, $settings_pro );
	}

}

if ( class_exists( 'WFFN_Pro_Core' ) ) {
	WFFN_Pro_Core::register( 'admin', 'WFFN_Pro_Admin' );
}
