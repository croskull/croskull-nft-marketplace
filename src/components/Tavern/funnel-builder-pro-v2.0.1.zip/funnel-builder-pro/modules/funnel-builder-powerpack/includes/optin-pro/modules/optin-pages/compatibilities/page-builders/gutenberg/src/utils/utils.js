/**
 * External dependencies
 */
import { isEmpty, values as __values, isEqual, noop, groupBy, cloneDeep, pickBy } from 'lodash';
import classNames from 'classnames';

/**
 * WordPress dependencies
 */
import { __ } from '@wordpress/i18n';
import { Button, Tooltip } from '@wordpress/components';
import { useState } from '@wordpress/element';
import { useSelect, useDispatch } from '@wordpress/data';

/**
 * Internal dependencies
 */
import { SVGBlob1, SVGSquare, SVGCircle, IconSquare, IconIndivisual } from './images';

const { i18n, products } = window.bwfop_funnels_data;

export const getCurrentScreen = () => {
	var deviceType = useSelect((select) => {
		const {
			__experimentalGetPreviewDeviceType = null,
		} = select('core/edit-post');
		return __experimentalGetPreviewDeviceType ? __experimentalGetPreviewDeviceType() : 'Desktop';
	}, []);
	deviceType = deviceType ? deviceType.toLowerCase() : 'desktop';
	return deviceType;
}
export const includeFont = (font) => {
	if (font) {
		const fonts = [
			font.desktop && font.desktop.family && !systemFonts.includes(font.desktop.family)
				? (
					font.desktop.family +
					':' +
					(font.desktop.weight ? font.desktop.weight : 'regular')
				).replace(/\s/g, '+')
				: '',
			font.tablet && font.tablet.family && !systemFonts.includes(font.desktop.family)
				? (
					font.tablet.family +
					':' +
					(font.tablet.weight ? font.tablet.weight : 'regular')
				).replace(/\s/g, '+')
				: '',
			font.mobile && font.mobile.family && !systemFonts.includes(font.desktop.family)
				? (
					font.mobile.family +
					':' +
					(font.mobile.weight ? font.mobile.weight : 'regular')
				).replace(/\s/g, '+')
				: '',
		].filter(function (el) {
			return el !== '';
		});
		if (fonts.length) {
			WebFont.load({
				google: {
					families: fonts,
				},
			});
		}
	}
};

/**
 *
 * @param {string} cssAttr created for padding and margin computation
 * @param {Object} data    padding, margin data collection
 * @param {string} screen  responsive screen
 * @return
 */
export const cssSpaceCompute = (cssAttr, data, screen = 'desktop') => {
	if (isEmpty(data[screen])) {
		return false;
	}

	if ('desktop' !== screen) {
		if (isEqual(data[screen], data.desktop)) {
			return false;
		}
	}
	const { unit, ...tempVal } = data[screen];
	const tempArr = __values(tempVal);

	if (tempArr.every((item) => item === tempArr[0])) {
		return `${cssAttr}: ${tempArr[0]}${unit};`;
	}

	let spaceCSS = '';
	if (!isEmpty(tempVal.top)) {
		spaceCSS += `${cssAttr}: ${tempVal.top}${unit};`;
	}
	if (!isEmpty(tempVal.right)) {
		spaceCSS += `${cssAttr}: ${tempVal.right}${unit};`;
	}
	if (!isEmpty(tempVal.bottom)) {
		spaceCSS += `${cssAttr}: ${tempVal.bottom}${unit};`;
	}
	if (!isEmpty(tempVal.left)) {
		spaceCSS += `${cssAttr}: ${tempVal.left}${unit};`;
	}
	return spaceCSS;
};

/**
 * Default colors for color pallete
 */
export const defaultColors = [
	{
		name: __('Black', i18n),
		slug: 'black',
		color: '#000000',
	},
	{
		name: __('Cyan bluish gray', i18n),
		slug: 'cyan-bluish-gray',
		color: '#abb8c3',
	},
	{
		name: __('White', i18n),
		slug: 'white',
		color: '#ffffff',
	},
	{
		name: __('Pale pink', i18n),
		slug: 'pale-pink',
		color: '#f78da7',
	},
	{
		name: __('Vivid red', i18n),
		slug: 'vivid-red',
		color: '#cf2e2e',
	},
	{
		name: __('Luminous vivid orange', i18n),
		slug: 'luminous-vivid-orange',
		color: '#ff6900',
	},
	{
		name: __('Luminous vivid amber', i18n),
		slug: 'luminous-vivid-amber',
		color: '#fcb900',
	},
	{
		name: __('Light green cyan', i18n),
		slug: 'light-green-cyan',
		color: '#7bdcb5',
	},
	{
		name: __('Vivid green cyan', i18n),
		slug: 'vivid-green-cyan',
		color: '#00d084',
	},
	{
		name: __('Pale cyan blue', i18n),
		slug: 'pale-cyan-blue',
		color: '#8ed1fc',
	},
	{
		name: __('Vivid cyan blue', i18n),
		slug: 'vivid-cyan-blue',
		color: '#0693e3',
	},
	{
		name: __('Vivid purple', i18n),
		slug: 'vivid-purple',
		color: '#9b51e0',
	},
];
export const textAlignSetting = [
	{
		id: 'left',
		icon: 'editor-alignleft',
		label: __('Left', i18n),
	},
	{
		id: 'center',
		icon: 'editor-aligncenter',
		label: __('Center', i18n),
	},
	{
		id: 'right',
		icon: 'editor-alignright',
		label: __('Right', i18n),
	},
	{
		id: 'justify',
		icon: 'editor-justify',
		label: __('Justify', i18n),
	},
];
export const textDecorationSetting = [
	{
		id: 'none',
		icon: 'editor-textcolor',
		label: __('None', i18n),
	},
	{
		id: 'line-through',
		icon: 'editor-strikethrough',
		label: __('Line Through', i18n),
	},
	{
		id: 'underline',
		icon: 'editor-underline',
		label: __('Underline', i18n),
	},
	{
		id: 'overline',
		icon: 'ellipsis',
		label: __('Overline', i18n),
	},
];

export const textTransformSetting = [
	{
		id: 'none',
		label: __('None', i18n),
	},
	{
		id: 'capitalize',
		label: __('Capitalize', i18n),
	},
	{
		id: 'uppercase',
		label: __('Uppercase', i18n),
	},
	{
		id: 'lowercase',
		label: __('Lowercase', i18n),
	},
];

const fontsarray =
	// eslint-disable-next-line camelcase
	typeof bwfop_funnels_data !== 'undefined' &&
		bwfop_funnels_data.bwf_g_font_names
		? bwfop_funnels_data.bwf_g_font_names.map((name) => {
			return { label: name, value: name, google: true };
		})
		: {};

export const FontFamilyList = [
	{
		type: 'group',
		label: __('Standard Fonts', i18n),
		options: [
			{
				label: 'System Default',
				value: '-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol"',
				google: false,
			},
			{
				label: 'Arial, Helvetica, sans-serif',
				value: 'Arial, Helvetica, sans-serif',
				google: false,
			},
			{
				label: '"Arial Black", Gadget, sans-serif',
				value: '"Arial Black", Gadget, sans-serif',
				google: false,
			},
			{
				label: 'Helvetica, sans-serif',
				value: 'Helvetica, sans-serif',
				google: false,
			},
			{
				label: '"Comic Sans MS", cursive, sans-serif',
				value: '"Comic Sans MS", cursive, sans-serif',
				google: false,
			},
			{
				label: 'Impact, Charcoal, sans-serif',
				value: 'Impact, Charcoal, sans-serif',
				google: false,
			},
			{
				label: '"Lucida Sans Unicode", "Lucida Grande", sans-serif',
				value: '"Lucida Sans Unicode", "Lucida Grande", sans-serif',
				google: false,
			},
			{
				label: 'Tahoma, Geneva, sans-serif',
				value: 'Tahoma, Geneva, sans-serif',
				google: false,
			},
			{
				label: '"Trebuchet MS", Helvetica, sans-serif',
				value: '"Trebuchet MS", Helvetica, sans-serif',
				google: false,
			},
			{
				label: 'Verdana, Geneva, sans-serif',
				value: 'Verdana, Geneva, sans-serif',
				google: false,
			},
			{
				label: 'Georgia, serif',
				value: 'Georgia, serif',
				google: false,
			},
			{
				label: '"Palatino Linotype", "Book Antiqua", Palatino, serif',
				value: '"Palatino Linotype", "Book Antiqua", Palatino, serif',
				google: false,
			},
			{
				label: '"Times New Roman", Times, serif',
				value: '"Times New Roman", Times, serif',
				google: false,
			},
			{
				label: 'Courier, monospace',
				value: 'Courier, monospace',
				google: false,
			},
			{
				label: '"Lucida Console", Monaco, monospace',
				value: '"Lucida Console", Monaco, monospace',
				google: false,
			},
		],
	},
	{
		type: 'group',
		label: __('Google Fonts', i18n),
		options: fontsarray,
	},
];
const systemFonts = FontFamilyList[0].options.map(opt => opt.value);

export const FontWeightList = [
	{
		value: 'inherit',
		label: __('Inherit', i18n),
	},
	{ value: '100', label: __('Thin 100', i18n) },
	{
		value: '200',
		label: __('Extra-Light 200', i18n),
	},
	{ value: '300', label: __('Light 300', i18n) },
	{ value: '400', label: __('Regular', i18n) },
	{
		value: '500',
		label: __('Medium 500', i18n),
	},
	{
		value: '600',
		label: __('Semi-Bold 600', i18n),
	},
	{ value: '700', label: __('Bold 700', i18n) },
	{
		value: '800',
		label: __('Extra-Bold 800', i18n),
	},
	{
		value: '900',
		label: __('Ultra-Bold 900', i18n),
	},
];

export const faGetSVGIcon = (prefix, iconName) => {
	const icon = faGetIcon(prefix, iconName);
	if (icon) {
		return icon.html[0];
	}
	return '';
};

export const faGetIcon = (prefix, iconName) => {
	if (!window.FontAwesome) {
		return null;
	}
	return window.FontAwesome.icon({ prefix, iconName });
};

export const faIsAPILoaded = () => {
	return !!window.FontAwesome;
};

export const faAPILoaded = () => {
	if (!window.FontAwesome) {
		return new Promise((resolve, reject) => {
			let timeoutCounter = 240;
			const interval = setInterval(() => {
				if (window.FontAwesome) {
					clearInterval(interval);
					resolve(true);
				} else if (timeoutCounter-- < 0) {
					clearInterval(interval);
					reject(false);
				}
			}, 250);
		});
	}
	return Promise.resolve(true);
};

export const faIconLoaded = (prefix, iconName) => {
	const icon = faGetIcon(prefix, iconName);
	if (!icon) {
		return new Promise((resolve, reject) => {
			let timeoutCounter = 240;
			const interval = setInterval(() => {
				const icon = faGetIcon(prefix, iconName);
				if (window.FontAwesome) {
					clearInterval(interval);
					resolve(icon);
				} else if (timeoutCounter-- < 0) {
					clearInterval(interval);
					reject(false);
				}
			}, 250);
		});
	}
	return Promise.resolve(icon);
};

export const getShapeSVG = (shape) => {
	const SVGS = {
		circle: SVGCircle,
		square: SVGSquare,
		blob1: SVGBlob1,
	};
	return !SVGS[shape] ? null : SVGS[shape];
};

export const DEFAULT_CHECK_SVG =
	'<svg data-prefix="fas" data-icon="check" class="svg-inline--fa fa-check fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M173.898 439.404l-166.4-166.4c-9.997-9.997-9.997-26.206 0-36.204l36.203-36.204c9.997-9.998 26.207-9.998 36.204 0L192 312.69 432.095 72.596c9.997-9.997 26.207-9.997 36.204 0l36.203 36.204c9.997 9.997 9.997 26.206 0 36.204l-294.4 294.401c-9.998 9.997-26.207 9.997-36.204-.001z"></path></svg>';
export const DEFAULT_TICK_SVG =
	'<svg data-prefix="far" data-icon="check-circle" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" > <path fill="currentColor" d="M256 8C119.033 8 8 119.033 8 256s111.033 248 248 248 248-111.033 248-248S392.967 8 256 8zm0 48c110.532 0 200 89.451 200 200 0 110.532-89.451 200-200 200-110.532 0-200-89.451-200-200 0-110.532 89.451-200 200-200m140.204 130.267l-22.536-22.718c-4.667-4.705-12.265-4.736-16.97-.068L215.346 303.697l-59.792-60.277c-4.667-4.705-12.265-4.736-16.97-.069l-22.719 22.536c-4.705 4.667-4.736 12.265-.068 16.971l90.781 91.516c4.667 4.705 12.265 4.736 16.97.068l172.589-171.204c4.704-4.668 4.734-12.266.067-16.971z" ></path> </svg>';

export const computeSpaceValue = (prop, data) => {
	const temp = lodash.cloneDeep(prop ? prop : {});
	Object.keys(temp).forEach(function (key, idx) {
		temp[key] = data[idx];
	});
	return temp;
};
const TABS = [
	{
		id: 'normal',
		label: __('Normal', i18n),
	},
	{
		id: 'hover',
		label: __('Hover', i18n),
	},
];

export const hoverTab = (screenType, setScreen, extraTab = [], customTab) => {
	const tabArr = customTab ? customTab : [...TABS, ...extraTab];
	return (
		<div className={classNames('bwf-responsive-tabs-list bwf-hover-tab')}>
			{tabArr.map((TData) => {
				return (
					<Button
						key={TData.id}
						onClick={() => {
							setScreen(TData.id);
						}}
						className={classNames('bwf-screen-tabs', {
							'active-screen': screenType === TData.id,
						})}
					>
						<Tooltip position="top center" text={TData.label}>
							<span className={'bwf-device-brick'}>
								{TData.label}
							</span>
						</Tooltip>
					</Button>
				);
			})}
		</div>
	);
}

export const rgba2hex = (orig) => {
	let a,
		rgb = orig
			.replace(/\s/g, '')
			.match(/^rgba?\((\d+),(\d+),(\d+),?([^,\s)]+)?/i),
		alpha = ((rgb && rgb[4]) || '').trim(),
		hex = rgb
			? (rgb[1] | (1 << 8)).toString(16).slice(1) +
			(rgb[2] | (1 << 8)).toString(16).slice(1) +
			(rgb[3] | (1 << 8)).toString(16).slice(1)
			: orig;

	if (alpha !== '') {
		a = alpha;
	} else {
		a = 1;
	}
	// multiply before convert to HEX
	a = ((a * 255) | (1 << 8)).toString(16).slice(1);
	hex = hex + a;
	return `#${hex}`;
};

export const DimensionToggle = (props) => {
	const {
		onChange = noop,
		initial = true,
	} = props;
	const [toggle, setToggle] = useState(initial);
	const handleToggle = () => {
		setToggle(!toggle)
		onChange(!toggle)
	}
	return (
		toggle
			? <span className={classNames('bwf-dimension-toggle')} onClick={handleToggle} title={'Edit All'}>
				<IconSquare />
			</span>
			: <span className={classNames('bwf-dimension-toggle')} onClick={handleToggle} title={'Edit Indivisual'}>
				<IconIndivisual />
			</span>
	)
}

export const breakPoints = (props = {}) => {
	const { clientId } = props;
	return {
		'tablet': clientId ? '5000px' : '1024px',
		'mobile': clientId ? '5000px' : '767px',
	}
}

/**
 * Simple CSS minification.
 *
 * @see https://stackoverflow.com/questions/15411263/how-do-i-write-a-better-regexp-for-css-minification-in-php
 *
 * @param {string} css CSS to minify.
 * @param {boolean} important Add !important to all rules.
 *
 * @return {string} Minified CSS
 */
export const minifyCSS = (css, important = false) => {
	const minified = css.replace(/\/\*.*?\*\//g, '') // Comments.
		.replace(/\n\s*\n/g, '') // Comments.
		.replace(/[\n\r \t]/g, ' ') // Spaces.
		.replace(/ +/g, ' ') // Multi-spaces.
		.replace(/ ?([,:;{}]) ?/g, '$1') // Extra spaces.
		.replace(/[^\}\{]+\{\}/g, '') // Blank selectors.
		.replace(/[^\}\{]+\{\}/g, '') // Blank selectors. Repeat to catch empty media queries.
		.replace(/;}/g, '}') // Trailing semi-colon.
		.trim()

	if (!important) {
		return minified
	}

	return minified
		.replace(/\s?\!important/g, '') // Remove all !important
		.replace(/([;\}])/g, ' !important$1') // Add our own !important.
		.replace(/\} !important\}/g, '}}') // Ending of media queries "}}" get an added !important from the previous line, remove it.
		.trim()
}

export const hasBlockVisible = (selector = '', props) => {
	if (!selector) {
		return '';
	}

	const { attributes: { vsdesk, vsmobile, vstablet } } = props;
	const screen = getCurrentScreen();
	let visibilityStyle = '';
	switch (screen) {
		case 'desktop':
			if (true === vsdesk) {
				visibilityStyle += `${selector}{opacity:0.1};`;
			}
			break;
		case 'tablet':
			if (true === vstablet) {
				visibilityStyle += `${selector}{opacity:0.1};`;
			}
			break;
		case 'mobile':
			if (true === vsmobile) {
				visibilityStyle += `${selector}{opacity:0.1};`;
			}
			break;
	}
	if (visibilityStyle) {
		return (
			<style>{visibilityStyle}</style>
		)
	}
	return '';
}

export const objectGrouped = (obj, groupBy) => {
	let StyleObj = {};
	for (let x in obj) {
		if (!StyleObj.hasOwnProperty(obj[x][groupBy])) {
			let newObj = pickBy(obj, { [groupBy]: obj[x][groupBy] });
			let data = cloneDeep(StyleObj);
			data[obj[x][groupBy]] = newObj;
			StyleObj = data;
		}
	}
	return StyleObj;
}

export const PanelTitle = [
	{
		'key': 'width',
		'label': __('Width', i18n),
	},
	{
		'key': 'Height',
		'label': __('Height', i18n),
	},
	{
		'key': 'padding',
		'label': __('Padding', i18n),
	},
	{
		'key': 'margin',
		'label': __('Margin', i18n),
	},
	{
		'key': 'border',
		'label': __('Border', i18n),
	},
	{
		'key': 'text',
		'label': __('Text', i18n),
	},
	{
		'key': 'color',
		'label': __('Button Color', i18n),
	},
	{
		'key': 'colorHover',
		'label': __('Color Hover', i18n),
	},
	{
		'key': 'seccolor',
		'label': __('Button Secondary Color', i18n),
	},
	{
		'key': 'seccolorHover',
		'label': __('Secondary Color Hover', i18n),
	},
	{
		'key': 'offercolor',
		'label': __('Offer Price Color', i18n),
	},
	{
		'key': 'offercolorHover',
		'label': __('Offer Price Color Hover', i18n),
	},
	{
		'key': 'backgroundcolor',
		'label': __('Background Color', i18n),
	},
	{
		'key': 'buttonbackground',
		'label': __('Button Background', i18n),
	},
	{
		'key': 'zIndex',
		'label': __('Z Index', i18n),
	},
	{
		'key': 'font',
		'label': __('Font', i18n),
	},
	{
		'key': 'boxShadow',
		'label': __('Box Shadow', i18n),
	},
	{
		'key': 'structure',
		'label': __('Structure', i18n),
	},
	{
		'key': 'space',
		'label': __('Spacing', i18n),
	},
	{
		'key': 'typography',
		'label': __('Button Typography', i18n),
	},
	{
		'key': 'sectypography',
		'label': __('Button Secondary Typography', i18n),
	},
	{
		'key': 'label',
		'label': __('Label', i18n),
	},
	{
		'key': 'asteriskcolor',
		'label': __('Asterisk', i18n),
	},
	{
		'key': 'input',
		'label': __('Input', i18n),
	},
	{
		'key': 'submitbutton',
		'label': __('Submit Button', i18n),
	},
	{
		'key': 'popupbtn',
		'label': __('Call to Action Button', i18n),
	},
	{
		'key': 'popupheading',
		'label': __('Popup Heading', i18n),
	},
	{
		'key': 'popupsubheading',
		'label': __('Popup Sub Heading', i18n),
	},
	{
		'key': 'popupheadingafter',
		'label': __('Popup Text After', i18n),
	},
	{
		'key': 'headingtypography',
		'label': __('Heading Typography', i18n),
	},
	{
		'key': 'headingcolor',
		'label': __('Heading Color', i18n),
	},
	{
		'key': 'subheadingtypography',
		'label': __('Sub Heading Typography', i18n),
	},
	{
		'key': 'subheading',
		'label': __('Sub Heading', i18n),
	},
	{
		'key': 'heading',
		'label': __('Heading', i18n),
	},
	{
		'key': 'subheadingcolor',
		'label': __('Popup Sub Heading Color', i18n),
	},
	{
		'key': 'background',
		'label': __('Background', i18n),
	},
	{
		'key': 'progressbar',
		'label': __('Popup Progress Bar', i18n),
	},
	{
		'key': 'popupcross',
		'label': __('Popup Close Button', i18n),
	},
	{
		'key': 'thumbnails',
		'label': __('Thumbnails', i18n),
	},
	{
		'key': 'featureimage',
		'label': __('Featured Image', i18n),
	},

];


export const AttributesType = {
	color: {
		type: 'color',
		label: __('Button Color', i18n),
		group: 'color',
	},
	colorHover: {
		type: 'color',
		label: __('Button Hover', i18n),
		group: 'color',
	},
	text: {
		type: 'text',
		label: __('', i18n),
		group: 'typography',
	},
	lineHeight: {
		type: 'rangeUnit',
		label: __('', i18n),
		group: 'typography',
	},
	letterSpacing: {
		type: 'rangeUnit',
		label: __('', i18n),
		group: 'typography',
	},
	font: {
		type: 'font',
		label: __('', i18n),
		group: 'typography',
	},
	background: {
		type: 'background',
		label: __('Background', i18n),
		group: 'background',
	},
	backgroundHover: {
		type: 'background',
		label: __('Background Hover', i18n),
		group: 'background',
	},
	padding: {
		type: 'padding',
		label: __('Padding', i18n),
		group: 'space',
	},
	margin: {
		type: 'margin',
		label: __('Margin', i18n),
		group: 'space',
	},
	width: {
		type: 'width',
		label: __('Width', i18n),
		group: 'structure',
	},
	minWidth: {
		type: 'width',
		label: __('Min Width', i18n),
		group: 'structure',
	},
	maxWidth: {
		type: 'width',
		label: __('Max Width', i18n),
		group: 'structure',
	},
	height: {
		type: 'height',
		label: __('Height', i18n),
		group: 'structure',
	},
	minHeight: {
		type: 'height',
		label: __('Min Height', i18n),
		group: 'structure',
	},
	maxHeight: {
		type: 'height',
		label: __('Max Height', i18n),
		group: 'structure',
	},
	boxShadow: {
		type: 'boxShadow',
		label: __('Box Shadow', i18n),
		group: 'boxShadow',
	},
	boxShadowHover: {
		type: 'boxShadow',
		label: __('Box Shadow Hover', i18n),
		group: 'boxShadow',
	},
};

/**
 * function to return string with capital letter.
 * @param {string} string the word string.
 * @returns {string} with capital letter.
 */
export const capitalizeFirstLetter = (string) => {
	return string.charAt(0).toUpperCase() + string.slice(1);
}


wp.domReady(function () {
	document.addEventListener('click', (e) => {
		if ('SELECT' === e.target.tagName && e.target.querySelector('[value="wfop-canvas.php"]')) {
			if ('wfop-canvas.php' === e.target.value) {
				document.body.classList.add('bwf-editor-width-canvas');
				document.body.classList.remove('bwf-editor-width-boxed');

			} else if ('wfop-boxed.php' === e.target.value) {
				document.body.classList.add('bwf-editor-width-boxed');
				document.body.classList.remove('bwf-editor-width-canvas');
			} else {
				document.body.classList.remove('bwf-editor-width-canvas');
				document.body.classList.remove('bwf-editor-width-boxed');
			}
		}
	});
});

export const fontCheck = (props) => {
	let fontArray = [];
	fontArray = pickBy(props, function (value, key) {

		return key.match(/font/gi);
	});
	if (fontArray && Object.keys(fontArray).length) {
		Object.keys(fontArray).forEach(font => includeFont(fontArray[font]));
	}
}
export const toolbarBGIndicator = (background, screen = 'desktop') => {
	let BGStyleIndicator = {};
	let calcStyle = [];
	if (background && background[screen]) {
		if (background[screen].color) {
			calcStyle.push(background[screen].color);
		}
		if (background[screen].gradient) {
			calcStyle.push(background[screen].gradient);
		}
		if (calcStyle.length > 0) {
			BGStyleIndicator = { background: calcStyle.join(' ') }
		}
	}
	return BGStyleIndicator;

}

export const WP_VERSION = window.hasOwnProperty( 'bwfop_funnels_data' ) ? bwfop_funnels_data.wp_version : '';