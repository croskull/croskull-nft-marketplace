<?php

class WFFN_RESET_API_EndPoint {

	private static $ins = null;

	/**
	 * WFFN_RESET_API_EndPoint constructor.
	 */
	public function __construct() {

		add_action( 'rest_api_init', [ $this, 'register_endpoint' ], 12 );
	}

	/**
	 * @return WFFN_RESET_API_EndPoint|null
	 */
	public static function get_instance() {
		if ( null === self::$ins ) {
			self::$ins = new self;
		}

		return self::$ins;
	}

	public function register_endpoint() {
		register_rest_route( 'woofunnels-analytics', '/funnels' . '/(?P<id>[\d]+)/reset/', array(
			array(
				'args'                => [],
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'reset_stats' ),
				'permission_callback' => array( $this, 'get_permission' ),
			),
		) );
	}

	/**
	 * @return bool
	 */
	public function get_permission() {
		return current_user_can( 'manage_options' );
	}

	public function reset_stats( $request ) {
		$response = array(
			'status' => false
		);

		$funnel_id = ( isset( $request['id'] ) && '' !== $request['id'] ) ? intval( $request['id'] ) : 0;

		if ( $funnel_id > 0 ) {
			$response = $this->get_all_funnel_posts( $funnel_id );
		}

		return rest_ensure_response( $response );
	}

	public function get_all_funnel_posts( $funnel_id ) {
		global $wpdb;

		$response = array(
			'status' => false
		);

		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT posts.ID FROM {$wpdb->posts} AS posts LEFT JOIN {$wpdb->postmeta} AS postmeta ON posts.ID = postmeta.post_id WHERE postmeta.meta_key = '_bwf_in_funnel' AND postmeta.meta_value LIKE %s ORDER BY posts.ID ASC", $funnel_id ) );

		if ( ! is_array( $ids ) || count( $ids ) === 0 ) {
			return $response;
		}

		if ( class_exists( 'WFACP_Contacts_Analytics' ) ) {
			$aero_obj = WFACP_Contacts_Analytics::get_instance();
			$aero_obj->reset_analytics( $funnel_id );
		}

		if ( class_exists( 'WFFN_Optin_Contacts_Analytics' ) ) {
			$optin_obj = WFFN_Optin_Contacts_Analytics::get_instance();
			$optin_obj->reset_analytics( $funnel_id );
		}

		if ( class_exists( 'WFOB_Contacts_Analytics' ) ) {
			$bump_obj = WFOB_Contacts_Analytics::get_instance();
			$bump_obj->reset_analytics( $funnel_id );
		}

		if ( class_exists( 'WFOCU_Contacts_Analytics' ) ) {
			$upsell_obj = WFOCU_Contacts_Analytics::get_instance();
			$upsell_obj->reset_analytics( $funnel_id );
		}

		$ids[] = $funnel_id;

		foreach ( $ids as $id ) {
			$query = "DELETE FROM " . $wpdb->prefix . "wfco_report_views WHERE object_id=" . $id;
			$wpdb->query( $query ); //phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		}

		WooFunnels_Transient::get_instance()->delete_transient( '_bwf_contacts_funnels_' . $funnel_id );
		$funnel = new WFFN_Funnel( $funnel_id );

		return array(
			'status'     => true,
			'count_data' => array(
				'contacts' => WFFN_Core()->wffn_contacts->get_total_count( $funnel_id ),
				'steps'    => $funnel->get_step_count(),
			)
		);

	}

}

WFFN_RESET_API_EndPoint::get_instance();