/**
 * WordPress dependencies
 */
import { __ } from '@wordpress/i18n';
const { i18n } = window.bwfop_funnels_data;

const BlockAttributesType = {

	/**
	 * Button
	 */
	alignment: {
		type: 'alignment',
		group: 'popupbtn',
		label: __('Alignment', i18n),
	},
	border: {
		type: 'border',
		group: 'popupbtn',
		label: __('Border', i18n),
	},
	color: {
		type: 'colorbtn',
		label: __('Text', i18n),
		group: 'popupbtn',
	},
	colorHover: {
		type: 'colorbtn',
		label: __('Text Hover', i18n),
		group: 'popupbtn',
	},
	text: {
		type: 'typographybtn',
		label: __('', i18n),
		group: 'popupbtn',
	},
	textHover: {
		type: 'typographybtn',
		label: __('Hover', i18n),
		group: 'popupbtn',
	},
	lineHeight: {
		type: 'typographybtn',
		label: __('', i18n),
		group: 'popupbtn',
	},
	lineHeightHover: {
		type: 'typographybtn',
		label: __('Hover', i18n),
		group: 'popupbtn',
	},
	letterSpacing: {
		type: 'typographybtn',
		label: __('', i18n),
		group: 'popupbtn',
	},
	letterSpacingHover: {
		type: 'typographybtn',
		label: __('Hover', i18n),
		group: 'popupbtn',
	},
	font: {
		type: 'typographybtn',
		label: __('', i18n),
		group: 'popupbtn',
	},
	fontHover: {
		type: 'typographybtn',
		label: __('Hover', i18n),
		group: 'popupbtn',
	},
	paddingButton: {
		type: 'paddingbtn',
		label: __('Padding', i18n),
		group: 'popupbtn',
	},
	marginButton: {
		type: 'marginbtn',
		label: __('Margin', i18n),
		group: 'popupbtn',
	},
	buttonBoxShadow: {
		type: 'boxShadow',
		group: 'popupbtn',
		label: __('Box Shadow', i18n),
	},
	buttonBoxShadowHover: {
		type: 'boxShadow',
		group: 'popupbtn',
		label: __('Box Shadow Hover', i18n),
	},

	buttonBackground: {
		type: 'background',
		group: 'popupbtn',
		label: __('Button Background', i18n),
	},
	buttonBackgroundHover: {
		type: 'background',
		group: 'popupbtn',
		label: __('Background Hover', i18n),
	},

	secondaryColor: {
		type: 'colorsec',
		group: 'popupbtn',
		label: __('Subtitle Text', i18n),
	},
	secondaryColorHover: {
		type: 'colorsec',
		group: 'popupbtn',
		label: __('Subtitle Text Hover', i18n),
	},
	secondaryFont: {
		type: 'typographysec',
		label: __('', i18n),
		group: 'popupbtn',
	},
	secondaryFontHover: {
		type: 'typographysec',
		label: __(' Hover', i18n),
		group: 'popupbtn',
	},
	secondaryText: {
		type: 'typographysec',
		label: __('', i18n),
		group: 'popupbtn',
	},
	secondaryTextHover: {
		type: 'typographysec',
		label: __('', i18n),
		group: 'popupbtn',
	},
	secondaryLineHeight: {
		type: 'typographysec',
		group: 'popupbtn',
		label: __('', i18n),
	},
	secondaryLineHeightHover: {
		type: 'typographysec',
		group: 'popupbtn',
		label: __('', i18n),
	},
	secondaryLetterSpacing: {
		type: 'typographysec',
		group: 'popupbtn',
		label: __('', i18n),
	},
	secondaryLetterSpacingHover: {
		type: 'typographysec',
		group: 'popupbtn',
		label: __('', i18n),
	},

	buttonWidth: {
		type: 'button',
		group: 'popupbtn',
		label: __('Submit Button', i18n),
	},


	/**
	 * Progress Bar
	 */
	progressBackground: {
		type: 'fill-bg',
		label: __('Fill color', i18n),
		group: 'progressbar',
	},
	progressBackgroundRemain: {
		type: 'background',
		label: __('', i18n),
		group: 'progressbar',
	},
	progressColor: {
		type: 'color',
		group: 'progressbar',
		label: __('Text Color', i18n),
	},
	progressBarPadding: {
		type: 'padding',
		group: 'progressbar',
		label: __('Padding', i18n),
	},
	progressFont: {
		type: 'font',
		label: __('', i18n),
		group: 'progressbar',
	},
	progressText: {
		type: 'text',
		label: __('', i18n),
		group: 'progressbar',
	},
	progressLineHeight: {
		type: 'rangeUnit',
		group: 'progressbar',
		label: __('', i18n),
	},
	progressLetterSpacing: {
		type: 'rangeUnit',
		group: 'progressbar',
		label: __('', i18n),
	},
	/**
	 * Heading
	 */
	headingColor: {
		type: 'headingcolor',
		group: 'popupheading',
		label: __('Text Color', i18n),
	},
	headingFont: {
		type: 'headingtypography',
		label: __('', i18n),
		group: 'popupheading',
	},
	headingText: {
		type: 'headingtypography',
		label: __('', i18n),
		group: 'popupheading',
	},
	headingLineHeight: {
		type: 'headingtypography',
		group: 'popupheading',
		label: __('', i18n),
	},
	headingLetterSpacing: {
		type: 'headingtypography',
		group: 'popupheading',
		label: __('', i18n),
	},

	subHeadingColor: {
		type: 'subheadingcolor',
		group: 'popupsubheading',
		label: __('Text Color', i18n),
	},
	subHeadingFont: {
		type: 'subheadingtypography',
		label: __('', i18n),
		group: 'popupsubheading',
	},
	subHeadingText: {
		type: 'subheadingtypography',
		label: __('', i18n),
		group: 'popupsubheading',
	},
	subHeadingLineHeight: {
		type: 'subheadingtypography',
		group: 'popupsubheading',
		label: __('', i18n),
	},
	subHeadingLetterSpacing: {
		type: 'subheadingtypography',
		group: 'popupsubheading',
		label: __('', i18n),
	},

	textAfterColor: {
		type: 'textaftercolor',
		group: 'popupheadingafter',
		label: __('Text Color', i18n),
	},
	textAfterFont: {
		type: 'textaftertypography',
		label: __('', i18n),
		group: 'popupheadingafter',
	},
	textAfterText: {
		type: 'textaftertypography',
		label: __('', i18n),
		group: 'popupheadingafter',
	},
	textAfterLineHeight: {
		type: 'textaftertypography',
		group: 'popupheadingafter',
		label: __('', i18n),
	},
	textAfterLetterSpacing: {
		type: 'textaftertypography',
		group: 'popupheadingafter',
		label: __('', i18n),
	},

	crossBorder: {
		type: 'border',
		group: 'popupcross',
		label: __('', i18n),
	},
	crossColor: {
		type: 'color',
		group: 'popupcross',
		label: __('Color', i18n),
	},
	crossColorHover: {
		type: 'color',
		group: 'popupcross',
		label: __('Color Hover', i18n),
	},
	crossBackgroundColor: {
		type: 'background',
		group: 'popupcross',
		label: __('Background Color', i18n),
	},
	crossBackgroundColorHover: {
		type: 'background',
		group: 'popupcross',
		label: __('Background Color Hover', i18n),
	},

	padding: {
		type: 'padding',
		label: __('Padding', i18n),
		group: 'space',
	},
	// margin: {
	// 	type: 'margin',
	// 	label: __('Margin', i18n),
	// 	group: 'space',
	// },
	width: {
		type: 'width',
		label: __('Width', i18n),
		group: 'structure',
	},
	minWidth: {
		type: 'width',
		label: __('Min Width', i18n),
		group: 'structure',
	},
	maxWidth: {
		type: 'width',
		label: __('Max Width', i18n),
		group: 'structure',
	},
	height: {
		type: 'height',
		label: __('Height', i18n),
		group: 'structure',
	},
	minHeight: {
		type: 'height',
		label: __('Min Height', i18n),
		group: 'structure',
	},
	maxHeight: {
		type: 'height',
		label: __('Max Height', i18n),
		group: 'structure',
	},
	background: {
		type: 'background',
		label: __('Background', i18n),
		group: 'background',
	},
	backgroundHover: {
		type: 'background',
		label: __('Background Hover', i18n),
		group: 'background',
	},
	boxShadow: {
		type: 'boxShadow',
		label: __('Box Shadow', i18n),
		group: 'boxShadow',
	},
	boxShadowHover: {
		type: 'boxShadow',
		label: __('Box Shadow Hover', i18n),
		group: 'boxShadow',
	},
};

export default BlockAttributesType