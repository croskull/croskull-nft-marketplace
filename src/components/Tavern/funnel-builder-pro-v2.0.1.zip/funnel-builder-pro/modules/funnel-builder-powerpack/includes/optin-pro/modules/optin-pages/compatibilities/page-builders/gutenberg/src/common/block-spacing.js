/**
 * External dependencies
 */
 import { cloneDeep, defaultsDeep, omit } from 'lodash';
 /**
  * WordPress dependencies
  */
 import { PanelBody } from '@wordpress/components';
 import { __ } from '@wordpress/i18n';
 /**
  * Internal dependencies
  */
 import { DimensionsControl } from 'BWFOP/components';
 const { i18n } = window.bwfop_funnels_data;
 
 
 const BWFBlockSpacing = (props) => {
     const { attributes: {margin, padding }, children } = props;
     const propsToPass = { ...omit( props, [ 'label', 'initialOpen' ] ) }
 
 
     return (
         <PanelBody scrollAfterOpen={false} title={props.label} initialOpen={props.initialOpen}>
            <DimensionsControl
                { ...propsToPass }
                label={ __( 'Margin', i18n ) }
                type={ 'margin' }
                attrKey={ 'margin' }
                attrVal={ margin }
                defaultSync={false}
            />
            <br />
            <br />
            <DimensionsControl
                { ...propsToPass }
                label={ __( 'Padding', i18n ) }
                attrKey={ 'padding' }
                attrVal={ padding }
                defaultSync={false}
            />
            { children }
         </PanelBody>
     )
 }
 BWFBlockSpacing.defaultProps = {
     label: __( 'Spacing', i18n ),
     initialOpen: true
 }
 export default BWFBlockSpacing;
 