import './frontend.scss';
document.addEventListener('DOMContentLoaded', (event) => {
    const btn = document.querySelectorAll( '.bwfop-poup-button-wrap .bwf-btn-popup');
    if ( btn ) {
        btn.forEach( button => {
            button.addEventListener( 'click', (e) => {
                button.parentElement.nextElementSibling.classList.add('show_popup_form');
            })
        })
    }
});