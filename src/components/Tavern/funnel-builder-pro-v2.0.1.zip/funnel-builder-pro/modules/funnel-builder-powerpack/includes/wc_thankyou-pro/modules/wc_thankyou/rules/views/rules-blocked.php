<?php global $wfty_is_rules_saved; ?>
<div id="wfty_funnel_rule_add_settings" data-is_rules_saved="no">
    <div class="wfty_welcome_wrap">
        <div class="wfty_welcome_wrap_in">
            <div class="wfty_welc_head">
                <div class="wfty_welc_icon"><span class="dashicons dashicons-info"></span></div>
                <div class="wfty_welc_title"> <?php esc_html_e( 'Rules for this variant are already set', 'funnel-builder' ); ?></div>
            </div>
            <div class="wfty_welc_text"><p><?php esc_html_e( 'Rules for this Thank You Page variant will be the same as that of the original variant.', 'funnel-builder' ); ?></p>
            </div>
        </div>
    </div>
</div>